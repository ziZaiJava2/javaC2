package com.zizaitianyuan.javac2.store.dao;

public interface TAG {
	public void update(String change,String name);
}
