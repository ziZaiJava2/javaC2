package com.zizaitianyuan.javac2.store.dto;

public class Category {
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
